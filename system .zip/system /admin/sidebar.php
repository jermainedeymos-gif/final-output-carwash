<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <title>Document</title>
</head>

<body>
    <div class="d-flex flex-column flex-shrink-0 p-3 text-bg-dark" style="width: 280px; height: 100vh;">
        <div>
            <h1 class="text-info">CRUD System</h1>
        </div>
        <hr><br>
        <ul class="nav nav-pills flex-column mb-auto">
            <h1 class="text-warning">Sidebar</h1>
            <li class="nav-item"> <a href="./Dashboard.php" class="nav-link text-white me-2" aria-current="page"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true">
                        <use xlink:href="#home"></use>
                    </svg>
                    Dashboard
                </a> </li>
            <li> <a href="./Services.php" class="nav-link text-white me-2"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true">
                        <use xlink:href="#speedometer2"></use>
                    </svg>
                    Services
                </a> </li>
            <li> <a href="./Staff.php" class="nav-link text-white me-2"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true">
                        <use xlink:href="#table"></use>
                    </svg>
                    Staff
                </a> </li>
            <li> <a href="./Bookings.php" class="nav-link text-white me-2"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true">
                        <use xlink:href="#grid"></use>
                    </svg>
                    Bookings
                </a> </li>
            <li> <a href="./Payments.php" class="nav-link text-white me-2"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true">
                        <use xlink:href="#people-circle"></use>
                    </svg>
                    Payments
                </a> </li>
            <li> <a href="./Portfolio.php" class="nav-link text-white me-2"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true">
                        <use xlink:href="#people-circle"></use>
                    </svg>
                    Portfolio
                </a> </li>

            <div class="dropdown nav-link active"> <a href="./Profile.php" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"> <img src="https://www.shutterstock.com/image-photo/hooded-hacker-online-security-concept-260nw-2415998581.jpg" alt="" width="32" height="32" class="rounded-circle me-2"> <strong>Profile</strong> </a>
                
                <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
                    <li><a class="dropdown-item" href="#">New project...</a></li>
                    <li><a class="dropdown-item" href="#">Settings</a></li>
                    <li><a class="dropdown-item" href="#">Profile</a></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="../views/dashboard.php">Sign out</a></li>
                </ul>
            </div>

            <hr>

            <br><br><br>
            <h1 class="text-warning">Pages</h1>
            <li class="nav-item"> <a href="./home-page.php" class="nav-link text-light me-2" aria-current="page"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true">
                        <use xlink:href="#home"></use>
                    </svg>
                    Home
                </a> </li>
            <li class="nav-item"> <a href="./services-page.php" class="nav-link text-light me-2" aria-current="page"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true">
                        <use xlink:href="#home"></use>
                    </svg>
                    Services
                </a> </li>
            <li class="nav-item"> <a href="./contact-page.php" class="nav-link text-light me-2" aria-current="page"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true">
                        <use xlink:href="#home"></use>
                    </svg>
                    Contact
                </a> </li>
            <li class="nav-item"> <a href="./about-page.php" class="nav-link text-light me-2" aria-current="page"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true">
                        <use xlink:href="#home"></use>
                    </svg>
                    About
                </a> </li>
            <li class="nav-item"> <a href="./bookings-page.php" class="nav-link text-light me-2" aria-current="page"> <svg class="bi pe-none me-2" width="16" height="16" aria-hidden="true">
                        <use xlink:href="#home"></use>
                    </svg>
                    Bookings
                </a> </li>
        </ul>
        <hr>
    </div>
</body>

</html>