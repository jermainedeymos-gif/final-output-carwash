<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
    <title>Services</title>
</head>

<body>
    <?php
    include "./sidebar.php";
    ?>

    <div class="admin-dashboard">
        <div class="">
            <h1 class="div1">Service</h1>
        </div>
    </div>
</body>

</html>