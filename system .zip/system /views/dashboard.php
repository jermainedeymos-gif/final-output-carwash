<?php
include "../partials/header.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="../assets/css/header.css">
    <link rel="stylesheet" href="../assets/css/custom.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="http://192.168.80.168/cwms/css/style.css">

    <!--Bootstrap cdn-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <!--jquery-->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <div class="hero-banner">
        <h1>Carwash Management System</h1>
    </div>
</head>

<body>

    <?php
    include("../carousel/carousel.php");
    ?>
    <hr>

    <!-- About Start -->
    <div class="about">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="about-img">
                        <img src="https://cdn.prod.website-files.com/659c0ff8fc0ce612198bddd3/666898e4a26d9cb62ab0a3d8_image%2023%20copy.jpg" alt="Image">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="section-header text-left">
                        <p>About Us</p>
                        <h2>car washing and detailing</h2>
                    </div>
                    <div class="about-content">
                        <p>
                            At Hydro Brite Car Wash, we provide professional car washing and detailing services to keep your vehicle looking its best. We treat every car with care, focusing on quality, attention to detail, and customer satisfaction.<br>
                            Our services include seat washing, vacuum cleaning, interior wet cleaning, and window wiping, all done by trained staff using safe, effective products. Whether it’s a quick refresh or a deep clean, we’re here to help your car look and feel like new.
                        </p>
                        <ul>
                            <li><i class="far fa-check-circle"></i>Seats washing</li>
                            <li><i class="far fa-check-circle"></i>Vacuum cleaning</li>
                            <li><i class="far fa-check-circle"></i>Interior wet cleaning</li>
                            <li><i class="far fa-check-circle"></i>Window wiping</li>
                        </ul>
                        <a class="btn btn-custom" href="../pages/about.php">Learn More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <!-- About End -->


    <!-- Service Start -->
    <div class="service">
        <div class="container">
            <div class="section-header text-center">
                <p>What We Do?</p>
                <h2>Premium Washing Services</h2>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="service-item">
                        <img id="ss" src="https://autoimage.capitalone.com/cms/Auto/assets/images/1616-hero-pressure-wash-a-car.jpg" width="100px" height="100px" alt="">
                        <h3 id="h3">Exterior Washing</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="service-item">
                        <img id="ss" src="https://media.istockphoto.com/id/1288964234/photo/car-detailing-service-deep-interior-cleaning.jpg?s=612x612&w=0&k=20&c=O1jFEKtCipreEAIOhEkIwYxkq0OBd8rMYe8bOFPngtc=" width="100px" height="100px" alt="">
                        <h3 id="h3">Interior Washing</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="service-item">
                        <img id="ss" src="https://m.media-amazon.com/images/I/61w5rRSbt2S._UF1000,1000_QL80_.jpg" width="100px" height="100px" alt="">
                        <h3 id="h3">Vacuum Cleaning</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="service-item">
                        <img id="ss" src="https://motorgy.b-cdn.net/live/CarImages/cbaee914-c0b4-4be6-bfaf-98401be09249.webp" width="100px" height="100px" alt="">
                        <h3 id="sw">Seats Washing</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="service-item ">
                        <img id="ss" src="https://metroautoglass.com.au/wp-content/uploads/car-window-cleaning.jpg" width="100px" height="100px" alt="">
                        <h3 id="h3">Window Wiping</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="service-item">
                        <img id="ss" src="https://media.istockphoto.com/id/1287044692/photo/worker-washing-red-car-with-sponge-on-a-car-wash.jpg?s=612x612&w=0&k=20&c=_6WO9k1qkDub5CAEQgnORMduUoQJkU6w3jjVQTdTdwQ=" width="100px" height="100px" alt="">
                        <h3 id="wc">Wet Cleaning</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="service-item">
                        <img id="ss" src="https://www.communityautoinc.com/Files/EmailCampaigns/AdobeStock_251971442.jpeg" width="100px" height="100px" alt="">
                        <h3 id="wc">Oil Changing</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="service-item">
                        <img id="ss" src="https://www.boschcarservice.com/xrm/media/services/brake_service_image_640w_360h.jpg" width="100px" height="100px" alt="">
                        <h3 id="bp">Brake Reparing</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <!-- Service End -->


    <!-- Price Start -->
    <div class="price ">
        <div class="container">
            <div class="section-header text-center">
                <p>Washing Plan</p>
                <h2>Choose Your Plan</h2>
            </div>
            <div class="row ">
                <div class="col-md-4 ">
                    <div class="price-item">
                        <div class="price-header">
                            <h3>Basic Cleaning</h3>
                            <h2><span>$</span><strong>10</strong><span>.99</span></h2>
                        </div>
                        <div class="price-body">
                            <ul>
                                <li><i class="far fa-check-circle"></i>Seats Washing</li>
                                <li><i class="far fa-check-circle"></i>Vacuum Cleaning</li>
                                <li><i class="far fa-check-circle"></i>Exterior Cleaning</li>
                                <li><i class="far fa-times-circle"></i>Interior Wet Cleaning</li>
                                <li><i class="far fa-times-circle"></i>Window Wiping</li>
                            </ul>
                        </div>
                        <script>
                            $(document).on("click", "#myModal", function() {
                                $("myModal").show();
                            })
                        </script>
                        <div class="price-footer">
                            <a class="btn btn-custom" data-toggle="modal" data-target="#myModal">Book Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="price-item featured-item">
                        <div class="price-header">
                            <h3>Premium Cleaning</h3>
                            <h2><span>$</span><strong>20</strong><span>.99</span></h2>
                        </div>
                        <div class="price-body">
                            <ul>
                                <li><i class="far fa-check-circle"></i>Seats Washing</li>
                                <li><i class="far fa-check-circle"></i>Vacuum Cleaning</li>
                                <li><i class="far fa-check-circle"></i>Exterior Cleaning</li>
                                <li><i class="far fa-check-circle"></i>Interior Wet Cleaning</li>
                                <li><i class="far fa-times-circle"></i>Window Wiping</li>
                            </ul>
                        </div>
                        <div class="price-footer">
                            <a class="btn btn-custom" data-toggle="modal" data-target="#myModal">Book Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="price-item">
                        <div class="price-header">
                            <h3>Complex Cleaning</h3>
                            <h2><span>$</span><strong>30</strong><span>.99</span></h2>
                        </div>
                        <div class="price-body">
                            <ul>
                                <li><i class="far fa-check-circle"></i>Seats Washing</li>
                                <li><i class="far fa-check-circle"></i>Vacuum Cleaning</li>
                                <li><i class="far fa-check-circle"></i>Exterior Cleaning</li>
                                <li><i class="far fa-check-circle"></i>Interior Wet Cleaning</li>
                                <li><i class="far fa-check-circle"></i>Window Wiping</li>
                            </ul>
                        </div>
                        <div class="price-footer">
                            <a class="btn btn-custom" data-toggle="modal" data-target="#myModal">Book Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Price End -->

    <!--Model-->
    <style>
        #f1 {
            width: 100%;
        }
    </style>
    <div class="modal fade" id="myModal" role="dialog" style="display: none;" aria-hidden="true">
        <form action="../page/priceModal-handler.php" method="post">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content" style="width: 100%;">
                    <div class="modal-header">
                        <h4 class="modal-title">Car Wash Booking</h4>
                    </div>
                    <div class="modal-body">
                        <form id="f1" method="post">
                            <p>
                                <select name="package_type" required class="form-control">
                                    <option value="">Package Type</option>
                                    <option value="BASIC CLEANING">BASIC CLEANING ($10.99)</option>
                                    <option value="PREMIUM CLEANING">PREMIUM CLEANING ($20.99)</option>
                                    <option value="COMPLEX CLEANING">COMPLEX CLEANING($30.99)</option>
                                </select>

                            </p>
                            <p>
                                <select name="washing_point" required class="form-control">
                                    <option value="">Select Washing Point</option>

                                    <option value="Cielo Car Washing Point">Cielo Car Washing Point (ABC Street New Delhi 1110001)</option>

                                    <option value="ABC Car Washing Point">ABC Car Washing Point (A3263 Sector 1- Noida 201301)</option>

                                    <option value="Matrix Car washing Point"> Matrix Car washing Point (H911 Indira Puram Ghaziabad 201017 UP)</option>

                                    <option value="Pawing Car Wash Center">Pawing Car Wash Center (Pawing, Palo, Leyte)</option>

                                    <option value="Poto's War Wash">Poto's War Wash (Pater St. Tacloban CIty)</option>

                                    <option value="Julita Matrix Center Point">Julita Matrix Center Point (Government Center, Palo Leyte, Sample)</option>
                                </select>
                            </p>
                            <p><input type="text" name="full_name" class="form-control" required placeholder="Full Name"></p>
                            <p><input type="text" name="mobile_no" class="form-control" pattern="[0-9]{10}" title="10 numeric characters only" required placeholder="Mobile No."></p>
                            <p>Wash Date <br><input type="date" name="wash_date" required class="form-control"></p>
                            <p>Wash Time <br><input type="time" name="wash_time" required class="form-control"></p>
                            <p><textarea name="message" class="form-control" placeholder="Message if any"></textarea></p>
                            <p><input type="submit" class="btn btn-custom" name="book" value="Book Now"></p>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </form>
    </div>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

    <?php
    include("../partials/footer.php");
    ?>
</body>

</html>