🧱 1️⃣ Folder Structure Overview
carwash-system/
├── admin/
│   ├── Dashboard.php
│   ├── Bookings.php
│   ├── Services.php
│   ├── Staff.php
│   ├── Payments.php
│   ├── Portfolio.php
│   ├── /pages/
│   │   ├── #
│   │   ├── #
│   │   ├── #
│   └── Logout.php
│
├── config/
│   ├── Database.php                │
│   ├── db.sql                      ├──> //=====> Backend <=====//
│   └── App.php                     │
│
├── controllers/
│   ├── MainController.php                
│   ├── BookingController.php       
│   ├── ClientController.php        │
│   ├── ServiceController.php       ├──> //=====> Backend <=====//
│   ├── UserController.php          │
│   └── AuthController.php          
│
├── models/                         
│   ├── Booking.php                 
│   ├── Client.php                  │
│   ├── Service.php                 ├──> //=====> Backend <=====//
│   ├── User.php                    │
│   ├── ActiveUser.php              
│   └── DefaultUser.php             
│
├── views/
│   ├── dashboard.php
│   ├── login.php
│   ├── /partials/
│   │   ├── header.php
│   │   ├── sidebar.php
│   │   ├── footer.php
│   ├── /bookings/
│   │   ├── list.php
│   │   ├── add.php
│   │   └── edit.php
│   ├── /clients/
│   │   ├── list.php
│   │   ├── add.php
│   │   └── edit.php
│   ├── /services/
│   │   ├── list.php
│   │   ├── add.php
│   │   └── edit.php
│   └── /users/
│       ├── list.php
│       ├── add.php
│       └── edit.php
│
├── public/
│   ├── index.php          <-- main entry (router)
│   ├── assets/
│   │   ├── css/
│   │   │   └── style.css
│   │   ├── js/
│   │   │   └── main.js
│   │   └── img/
│   └── uploads/
│
└── includes/
    └── functions.php