// app.js - frontend-only logic; uses placeholder endpoints located at /page/*.php
// Note: Because there's no backend yet, these calls will fail. They are here as ready-to-wire hooks.

document.addEventListener('DOMContentLoaded', () => {
  // Simple toast helper
  window.appToast = function(message, type='success') {
    const holder = document.getElementById('toastHolder');
    if (!holder) return;
    const id = 't'+Date.now();
    const toastEl = document.createElement('div');
    toastEl.className = `toast align-items-center text-bg-${type} border-0 show`;
    toastEl.setAttribute('role','alert');
    toastEl.setAttribute('aria-live','assertive');
    toastEl.setAttribute('aria-atomic','true');
    toastEl.style.minWidth = '200px';
    toastEl.innerHTML = `
      <div class="d-flex">
        <div class="toast-body">${message}</div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>`;
    holder.appendChild(toastEl);
    setTimeout(()=>{ toastEl.remove(); }, 4000);
  };

  // Initialize any DataTables present
  if (typeof $ !== 'undefined' && $.fn.dataTable) {
    $('.datatable').DataTable({
      responsive: true,
      pageLength: 10
    });
  }

  // Example: open booking modal from dashboard button
  const bookingNowBtn = document.getElementById('bookingNowBtn');
  if (bookingNowBtn) {
    bookingNowBtn.addEventListener('click', () => {
      const modal = new bootstrap.Modal(document.getElementById('bookingModal'));
      modal.show();
    });
  }

  // Example placeholder: submit booking form (sends to /page/booking-handler.php?function=add)
  const bookingForm = document.getElementById('bookingForm');
  if (bookingForm) {
    bookingForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const data = new FormData(bookingForm);
      // Convert to object example
      const payload = {};
      data.forEach((v,k) => payload[k] = v);
      // Placeholder fetch (replace URL with your real handler)
      try {
        const res = await fetch('/page/booking-handler.php?function=add', {
          method: 'POST',
          body: data
        });
        if (!res.ok) throw new Error('Server returned '+res.status);
        appToast('Booking submitted!', 'success');
        bookingForm.reset();
        bootstrap.Modal.getInstance(document.getElementById('bookingModal')).hide();
      } catch (err) {
        console.error(err);
        appToast('Booking failed (no backend yet)', 'danger');
      }
    });
  }

  // Additional wiring could be added for edit/delete actions once backend exists
});
