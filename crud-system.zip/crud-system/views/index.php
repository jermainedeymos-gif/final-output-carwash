<?php include "includes/header.php"; ?>

<!-- Dashboard quick actions -->
<div class="row g-4">
    <div class="col-md-6">
        <div class="card card-compact p-4">
            <h5>Quick Actions</h5>
            <p class="text-muted">Add bookings, check customers, manage services.</p>
            <div class="d-flex gap-2">
                <a href="bookings.php" class="btn btn-danger"><i class="fas fa-calendar-check me-2"></i>Bookings</a>
                <a href="customers.php" class="btn btn-outline-primary"><i class="fas fa-users me-2"></i>Customers</a>
                <a href="services.php" class="btn btn-outline-success"><i class="fas fa-concierge-bell me-2"></i>Services</a>
                <button id="bookingNowBtn" class="btn btn-outline-dark"><i class="fas fa-plus me-2"></i>Quick Book</button>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card card-compact p-4">
            <h5>Stats</h5>
            <div class="row text-center">
                <div class="col">
                    <h3 id="statBookings">0</h3><small class="text-muted">Bookings</small>
                </div>
                <div class="col">
                    <h3 id="statCustomers">0</h3><small class="text-muted">Customers</small>
                </div>
                <div class="col">
                    <h3 id="statRevenue">₱0.00</h3><small class="text-muted">Revenue</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent bookings (table visually filled with placeholder rows) -->
<div class="card card-compact mt-4 p-3">
    <h5>Recent Bookings</h5>
    <table class="table table-striped datatable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Service</th>
                <th>Date</th>
                <th>Time</th>
                <th class="no-sort">Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Placeholder rows -->
            <tr>
                <td>1</td>
                <td>Juan Dela Cruz</td>
                <td>Basic Wash</td>
                <td>2025-10-01</td>
                <td>10:00</td>
                <td>
                    <button class="btn btn-sm btn-primary"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
            <tr>
                <td>2</td>
                <td>Maria Santos</td>
                <td>Full Detail</td>
                <td>2025-10-02</td>
                <td>14:00</td>
                <td>
                    <button class="btn btn-sm btn-primary"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<!-- Booking modal (used by Quick Book) -->
<div class="modal fade" id="bookingModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form id="bookingForm" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Quick Booking</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Full Name</label>
                        <input name="name" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Phone</label>
                        <input name="phone" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Service</label>
                        <select name="service" class="form-select" required>
                            <option value="">Choose...</option>
                            <option>Basic Wash</option>
                            <option>Full Detail</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Date</label>
                        <input name="date" type="date" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Time</label>
                        <input name="time" type="time" class="form-control" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Notes</label>
                        <textarea name="notes" class="form-control"></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-danger" type="submit">Submit Booking</button>
            </div>
        </form>
    </div>
</div>

<?php include "./includes/footer.php"; ?>