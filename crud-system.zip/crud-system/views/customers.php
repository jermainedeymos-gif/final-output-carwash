<?php include "includes/header.php"; ?>

<div class="d-flex justify-content-between mb-3">
    <h4>Customers</h4>
    <div>
        <button id="addCustomerBtn" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#customerModal"><i class="fas fa-plus me-1"></i> Add Customer</button>
    </div>
</div>

<div class="card card-compact p-3">
    <table id="customersTable" class="table table-striped datatable" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th class="no-sort">Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- placeholders -->
            <tr>
                <td>1</td>
                <td>Juan Dela Cruz</td>
                <td>juan@example.com</td>
                <td>09171234567</td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-primary" data-action="edit"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-danger" data-action="delete"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
            <tr>
                <td>2</td>
                <td>Maria Santos</td>
                <td>maria@example.com</td>
                <td>09177654321</td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-primary" data-action="edit"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-danger" data-action="delete"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<!-- Customer Modal (Add/Edit) -->
<div class="modal fade" id="customerModal" tabindex="-1">
    <div class="modal-dialog">
        <form id="customerForm" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="customerModalTitle">Add Customer</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="customer_id" id="customer_id">
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input id="cust_name" name="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input id="cust_email" name="email" type="email" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">Phone</label>
                    <input id="cust_phone" name="phone" class="form-control">
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button id="customerSaveBtn" class="btn btn-danger" type="submit">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
    // UI wiring for customers page (frontend-only)
    document.addEventListener('DOMContentLoaded', () => {
        $('.datatable').DataTable();

        // Add button resets form for create
        document.getElementById('addCustomerBtn').addEventListener('click', () => {
            document.getElementById('customerForm').reset();
            document.getElementById('customerModalTitle').textContent = 'Add Customer';
            document.getElementById('customer_id').value = '';
        });

        // Table button actions (edit/delete) - purely UI, no backend
        document.querySelectorAll('#customersTable .table-actions button').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = btn.getAttribute('data-action');
                const tr = btn.closest('tr');
                const id = tr.children[0].textContent.trim();
                const name = tr.children[1].textContent.trim();
                const email = tr.children[2].textContent.trim();
                const phone = tr.children[3].textContent.trim();

                if (action === 'edit') {
                    document.getElementById('customerModalTitle').textContent = 'Edit Customer';
                    document.getElementById('customer_id').value = id;
                    document.getElementById('cust_name').value = name;
                    document.getElementById('cust_email').value = email;
                    document.getElementById('cust_phone').value = phone;
                    new bootstrap.Modal(document.getElementById('customerModal')).show();
                } else if (action === 'delete') {
                    if (confirm('Delete customer ID ' + id + '?')) {
                        // Here you would call your backend to delete
                        // Example: fetch('/page/customer-handler.php?function=delete', { method:'POST', body: new FormData(... ) })
                        appToast('Delete simulated (no backend)', 'warning');
                        tr.remove();
                    }
                }
            });
        });

        // Handle form submit (UI only)
        document.getElementById('customerForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const id = document.getElementById('customer_id').value;
            if (id) {
                appToast('Customer update simulated (no backend)', 'success');
            } else {
                appToast('Customer create simulated (no backend)', 'success');
            }
            bootstrap.Modal.getInstance(document.getElementById('customerModal')).hide();
        });
    });
</script>

<?php include "includes/footer.php"; ?>