<?php
// footer.php - include at bottom of page
?>
</div> <!-- /container -->

<footer class="bg-dark text-light py-4 mt-5">
    <div class="container d-flex justify-content-between">
        <div>&copy; <?= date('Y') ?> CarWash Management</div>
        <div>Built with <i class="fas fa-heart text-danger"></i></div>
    </div>
</footer>

</body>

</html>